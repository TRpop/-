public interface Heap extends PriorityQueue {
    void heapify(int index);
    void buildHeap();
}
