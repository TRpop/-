
public class MainClass_03_201502273 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PerformanceMeasurement p = new PerformanceMeasurement();
		
		p.generateData();
		p.testSortedArrayBag();
		p.testSortedLinkedBag();
	}

}
